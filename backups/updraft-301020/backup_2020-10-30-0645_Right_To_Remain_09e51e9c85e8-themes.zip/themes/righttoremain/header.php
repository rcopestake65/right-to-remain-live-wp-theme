<!DOCTYPE html>

<head>
    <?php wp_head();?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <link rel="canonical" href="#" />
    <title>Right to Remain - Asylum Journey</title>
</head>

<body <?php body_class();?> style="background-color:<?php the_field('background_colour'); ?>">